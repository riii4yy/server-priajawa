Letakkan foto galeri di sini dengan nama:
foto1.jpg, foto2.jpg, foto3.jpg, dst.

Sesuaikan jumlah & caption di array `gallery` pada script.js.
