Letakkan file musik (mp3) di sini dengan nama:
track1.mp3, track2.mp3, track3.mp3, dst.

Sesuaikan judul & jumlah di array `playlist` pada script.js.
