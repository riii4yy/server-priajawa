Letakkan di sini:
- logo.png         -> logo komunitas (dipakai di navbar, hero, footer)
- favicon.png       -> versi favicon dari logo (disarankan 512x512 atau 32x32)
- staff-owner.jpg   -> foto Riii4yy (Owner)
- staff-admin.jpg   -> foto Iel (Admin)
- staff-mod.jpg     -> foto Vympel (Moderator)

Catatan: untuk foto staff, lihat instruksi di README.md utama proyek
untuk menyambungkan foto ke kartu staff.
